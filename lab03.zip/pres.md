---
## Front matter
title: "Laboratory work report №3


mathematical modeling"


subtitle: "Модель боевых действий"
author: "Выполнил: Леснухин Даниил Дмитриевич, 


НПИбд-02-22, 1132221553"

## Generic otions
lang: ru-RU


## Bibliography
bibliography: bib/cite.bib
csl: pandoc/csl/gost-r-7-0-5-2008-numeric.csl

## Pdf output format
toc: true # Table of contents
toc-depth: 2
lof: true # List of figures
fontsize: 12pt
linestretch: 1.5
papersize: a4
documentclass: scrreprt
## I18n polyglossia
polyglossia-lang:
  name: russian
  options:
	- spelling=modern
	- babelshorthands=true
polyglossia-otherlangs:
  name: english
## I18n babel
babel-lang: russian
babel-otherlangs: english
## Fonts
mainfont: "Times New Roman"
mainfontoptions: Ligatures=TeX
romanfontoptions: Ligatures=TeX
sansfontoptions: Ligatures=TeX,Scale=MatchLowercase
monofontoptions: Scale=MatchLowercase,Scale=0.9
## Biblatex
biblatex: true
biblio-style: "gost-numeric"
biblatexoptions:
  - parentracker=true
  - backend=biber
  - hyperref=auto
  - language=auto
  - autolang=other*
  - citestyle=gost-numeric
## Pandoc-crossref LaTeX customization
figureTitle: "Рис."
tableTitle: "Таблица"
listingTitle: "Листинг"
lofTitle: "Список иллюстраций"
lolTitle: "Листинги"
## Misc options
indent: true
header-includes:
  - \usepackage{indentfirst}
  - \usepackage{float} # keep figures where there are in the text
  - \floatplacement{figure}{H} # keep figures where there are in the text
---

# Цель работы
**Цель работы:**
Изучить и применить математические модели Ланчестера для описания и анализа боевых действий в различных сценариях (между регулярными войсками, между регулярными войсками и партизанами, а также между партизанскими отрядами). Научиться численно решать системы дифференциальных уравнений и строить графики изменения численности войск для оценки динамики и выявления условий победы сторон.



# Задание 
**Задание** 
Рассмотри три случая ведения боевых действий: 
1. Боевые действия между регулярными войсками
2. Боевые действия с участием регулярных войск и партизанских отрядов  



 
# Выполнение лабораторной работы
**Выполнение лабораторной работы:**
Формула для выбора варианта лабораторной работы (1132221553%70) + 1 = 44

# Постановка задачи конкретному варианту. Рис. 1

![Лабораторная работа №3. Вариант 44](C:\Users\User\OneDrive\Рабочий стол\матмод\lab03\screenshots\Снимок экрана 2025-03-22 013200.png)
 
# Для выполнения задания создадим численное решение обеих моделей и построим графики изменения численностий армий x(t) и y(t)

# В первую очередь, реализуем систему дифференциальных уравнений с заданными начальными условиями для обеих моделей. Вычисления будут выполнены в Python с использованием библиотеки SciPy для численного решения дифференциальных уравнений.

1. Модель боевых действий между регулярными войсками

        dx\dt = -0.41x(t) - 0,76y(t) + |sin(t + 3)| 
        dy\dt = -0.59x(t) - 0,63y(t) + |cos(t + 2)|

2. Модель боевых действий с участием регулярных войск и партизан 

        dx\dt = 0,37x(t) - 0,76y(t) + |sin(6t)| 
        dy \ dt = -0,32x(t) - 0,61y(t ) + |cos(7t)|



# Построение модели 
**Построение модели**
```python
import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp

# Начальные параметры
x0 = 38000  # начальная численность армии X
y0 = 29000  # начальная численность армии Y
t_span = (0, 50)  # временной интервал (от 0 до 50)
t_eval = np.linspace(t_span[0], t_span[1], 500)  # точки времени для анализа

# Первая модель
def model1(t, z):
    x, y = z
    dxdt = -0.41 * x - 0.76 * y + abs(np.sin(t + 3))
    dydt = -0.59 * x - 0.63 * y + abs(np.cos(t + 2))
    return [dxdt, dydt]

# Вторая модель
def model2(t, z):
    x, y = z
    dxdt = 0.37 * x - 0.76 * y + abs(np.sin(6 * t))
    dydt = -0.32 * x - 0.61 * y + abs(np.cos(7 * t))
    return [dxdt, dydt]

# Третья модель
def model3(t, z):
    x, y = z
    dxdt = -0.45 * x - 0.85 * y + abs(np.sin(2 * t + 1))
    dydt = -0.52 * x - 0.75 * y + abs(np.cos(3 * t + 1.5))
    return [dxdt, dydt]

# Решение первой модели
sol1 = solve_ivp(model1, t_span, [x0, y0], t_eval=t_eval)

# Решение второй модели
sol2 = solve_ivp(model2, t_span, [x0, y0], t_eval=t_eval)

# Решение третьей модели
sol3 = solve_ivp(model3, t_span, [x0, y0], t_eval=t_eval)

# Построение графиков
plt.figure(figsize=(14, 10))

# Первая модель
plt.subplot(3, 1, 1)
plt.plot(sol1.t, sol1.y[0], label="Армия X", color="blue")
plt.plot(sol1.t, sol1.y[1], label="Армия Y", color="red")
plt.title("Модель 1: Боевые действия между регулярными войсками")
plt.xlabel("Время")
plt.ylabel("Численность войск")
plt.legend()
plt.grid()

# Вторая модель
plt.subplot(3, 1, 2)
plt.plot(sol2.t, sol2.y[0], label="Армия X", color="blue")
plt.plot(sol2.t, sol2.y[1], label="Армия Y", color="red")
plt.title("Модель 2: Боевые действия с участием регулярных войск и партизанских отрядов")
plt.xlabel("Время")
plt.ylabel("Численность войск")
plt.legend()
plt.grid()

# Третья модель
plt.subplot(3, 1, 3)
plt.plot(sol3.t, sol3.y[0], label="Армия X", color="blue")
plt.plot(sol3.t, sol3.y[1], label="Армия Y", color="red")
plt.title("Модель 3: Дополнительная модель боевых действий")
plt.xlabel("Время")
plt.ylabel("Численность войск")
plt.legend()
plt.grid()

plt.tight_layout()
plt.show()
```
В результате получаем следующий график. Рис. 2

![Отображение графика](C:\Users\User\OneDrive\Рабочий стол\матмод\lab03\screenshots\Снимок экрана 2025-03-22 010500.png)

# Итоги первой модели
**Итоги первой модели**

* Армия Y оказывается в менее выгодном положении из-за большей уязвимости (более высокий коэффициент воздействия −0.59x на армию Y).

* Если численность обеих армий начнёт снижаться, армия X будет постепенно доминировать. При долгосрочных боевых действиях численность обеих армий может стать критически низкой.

# Итоги второй модели

**Итоги второй модели**
* Армия X** получает преимущество благодаря положительному эффекту роста (+0.37x), что может отражать превосходство в стратегии или поддержку со стороны союзников.

* Армия Y** находится в уязвимом положении, но снижение её потерь (−0.61y) указывает на возможность долгосрочного выживания, если удастся сдерживать армию X.


# Условия победы
**Условия победы**
* Армия X побеждает, если x(t) остаётся положительным, а y(t) становится отрицательным или стремится к нулю.

* Армия Y может выиграть, если соотношение начальных параметров или коэффициентов изменится так, что уравнения начнут быстрее уничтожать численность X.   	

![Условия победы](C:\Users\User\OneDrive\Рабочий стол\матмод\lab03\screenshots\Снимок экрана 2025-03-22 012324.png)






# Вывод

 В ходе выполнения лабораторной работы:
1. Были реализованы три математические модели боевых действий, описывающие различные сценарии противостояния.
2. Построены графики изменения численности войск для каждого из сценариев, которые наглядно демонстрируют влияние параметров системы (коэффициентов смертности, эффективности боевых действий, подкреплений) на исход войны.
3. Проанализированы условия, при которых одна из сторон может одержать победу, а также выявлена зависимость исхода войны от начальных численностей войск и параметров модели.
4. Получен практический навык работы с системами дифференциальных уравнений и их численного решения с использованием Python.



